document.getElementById("dataForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const image = document.getElementById("image").files[0];
    const sleep = document.getElementById("sleep").value;
    const steps = document.getElementById("steps").value;
    const findrisc = document.getElementById("findrisc").value;

    const result = {
        imageUploaded: image ? "Ya" : "Tidak",
        sleepQuality: sleep,
        dailySteps: steps,
        findriscAnswers: findrisc
    };

    localStorage.setItem("healthData", JSON.stringify(result));
    window.location.href = "results.html";
});